package softuni.exam.config;

@Configuration
public class ApplicationBeanConfiguration {

	//ToDo

    @Bean
    public Gson gson() {
        return null;
    }

    @Bean
    public ValidationUtil validationUtil() {
        return null;
    }

    @Bean
    public ModelMapper modelMapper() {
        return null;
    }


}
