create procedure usp_deposit_money(IN account_id int, IN money_amount decimal(8,4))
begin
start TRANSACTION;
if money_amount<0 then rollback;
else UPDATE accounts as a
set a.balance = a.balance+money_amount
where a.id = account_id;
end if;
SELECT a.id, a.account_holder_id, a.balance
from accounts as a
where a.id = account_id;
end;

