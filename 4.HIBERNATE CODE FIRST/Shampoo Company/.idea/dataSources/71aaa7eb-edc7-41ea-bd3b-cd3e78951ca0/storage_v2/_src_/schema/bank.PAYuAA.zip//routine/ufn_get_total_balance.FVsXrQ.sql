create function ufn_get_total_balance(id int) returns decimal
begin
declare total_amount decimal(14,4);
set total_amount = (select sum(a.balance)
from accounts as a
where a.account_holder_id = id);
return total_amount;
end;

