create function ufn_calculate_future_value(sum_now double(25,12), yearly_interest_rate double,
                                           number_of_years int) returns double(12,4)
begin
declare result double(12,4);
set result = sum_now*(pow((1+yearly_interest_rate),number_of_years));
return result;
end;

