create procedure usp_calculate_future_value_for_account(IN account_id int, IN interest_rate double(12,4))
BEGIN
SELECT a.id, ah.first_name, ah.last_name, a.balance as current_balance,
ufn_calculate_future_value(a.balance, interest_rate,5) as balance_in_5_years
from accounts as a
join account_holders as ah
on a.account_holder_id = ah.id
GROUP BY a.id
HAVING a.id = account_id;
end;

