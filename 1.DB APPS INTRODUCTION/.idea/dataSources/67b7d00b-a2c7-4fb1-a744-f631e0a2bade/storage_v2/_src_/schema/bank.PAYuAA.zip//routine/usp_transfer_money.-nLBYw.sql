create procedure usp_transfer_money(IN from_account_id int, IN to_account_id int, IN money_amount decimal(19))
begin
start TRANSACTION;
if (money_amount<0 and round(money_amount,4) <>money_amount) 
or money_amount>(select a.balance from accounts as a WHERE a.id = from_account_id)
then rollback;
else UPDATE accounts as a
set a.balance = a.balance+money_amount
where a.id = to_account_id;
update accounts as ac
set ac.balance = ac.balance - money_amount
where ac.id = from_account_id;
end if;
end;

