create procedure usp_get_holders_full_name()
begin
select concat(h.first_name, ' ', h.last_name) as full_name
from account_holders as h
order by full_name, h.id;
end;

