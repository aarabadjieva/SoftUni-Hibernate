create procedure usp_get_older(IN id int)
BEGIN
UPDATE minions as m SET m.age = m.age+1
  WHERE m.id = id;
end;

