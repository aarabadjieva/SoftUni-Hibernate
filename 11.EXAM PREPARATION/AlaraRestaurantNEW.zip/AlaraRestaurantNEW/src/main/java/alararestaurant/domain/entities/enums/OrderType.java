package alararestaurant.domain.entities.enums;

public enum OrderType {

    ForHere, ToGo
}
